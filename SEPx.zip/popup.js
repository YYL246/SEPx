let bgpage = chrome.extension.getBackgroundPage()
let bibliography = bgpage.bibliography
document.write(bibliography)
